Arab Majlis LIVE - Free browser prototype v0.1

Open index.html in a browser. On iPad, a hosted HTTPS URL is more reliable than opening a downloaded HTML file directly. You can upload index.html to a free static hosting service from Safari, subject to its account and free-tier conditions.

Features: Arabic RTL, portrait stage, stylized pseudo-3D majlis drawn with Canvas, mock comment and gift buttons, queued actions, animated characters, leaderboard.

NOT included: real TikTok LIVE comment/gift connection, cloud streaming, TikTok stream key, real Unity 3D. These require separate eligibility and integrations.

Suggested iPad test: host index.html on an HTTPS static site, open it in Safari, press the buttons, and test TikTok mobile screen sharing only if available on your account. One iPad cannot be guaranteed to screen share and simultaneously receive real-time TikTok events.
